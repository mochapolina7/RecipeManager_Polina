/**
 * Lead Author(s):
 * @author Polina Mochalova
 *
 * Other Contributors:
 * N/A
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 *
 * Date/Version: 04.23.2026
 *
 * Responsibilities of class:
 * DessertRecipe is-a Recipe.
 */
public class DessertRecipe extends Recipe
{
    public DessertRecipe(String name, String category, int cookTime, String instructions)
    {
        super(name, category, cookTime, instructions);
    }
}